package Evaluator;

public class Operand {

  public Operand( String token ) {//push it onto the operator stack?
      

  }

  public Operand( int value ) {//push 

      
  }

  public int getValue() {
      return 0;
  }

  public static boolean check( String token ) {
      return false;
  }
  
  
}
