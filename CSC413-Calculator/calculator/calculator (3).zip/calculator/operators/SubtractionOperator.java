
package operators;

/**
 *
 * @author Gabriel
 */
public class SubtractionOperator {
    
    public SubtractionOperator(int op1, int op2){
    int temp;
    temp= op2-op1;
}
    
}
