
package operators;

/**
 *
 * @author Gabriel
 */
public class MultiplicationOperator {
    
    public MultiplicationOperator(int op1, int op2){
        int temp;
        temp=op2*op1;
        
    }
    
}
