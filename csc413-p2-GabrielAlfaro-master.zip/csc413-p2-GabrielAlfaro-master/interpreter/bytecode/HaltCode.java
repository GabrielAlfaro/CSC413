/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interpreter.bytecode;

/**
 *
 * @author Gabriel
 */
public class HaltCode {
    public HaltCode(){
    System.exit(0);
    //stop the Code from running 
    }
    
}
