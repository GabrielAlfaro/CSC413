package Evaluator;

public class Operand {

  public Operand( String token ) {

  }

  public Operand( int value ) {

  }

  public int getValue() {
      return 0;
  }

  public static boolean check( String token ) {
      return false;
  }
}
