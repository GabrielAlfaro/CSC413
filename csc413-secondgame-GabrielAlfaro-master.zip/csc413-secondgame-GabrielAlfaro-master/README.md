# csc413-SecondGame

## Student Name : Gabriel Alfaro
## Student ID : 913142053

IDE: NetBeans IDE 8.2
Java Version: JDK 1.8 (Default)
Git Hub: https://github.com/csc413-02-su18/csc413-secondgame-GabrielAlfaro

Run the  class RainbowReef2.java class
Controls for Player:
Movement: left arrow key, right arrow key 


Project is not complete.
Project has levels not called or initialized. 
