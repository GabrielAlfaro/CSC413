
package tankgame;

/**
 *
 * @author Gabriel
 */
public class PowerUp {
    //was not able to implement
    
}
